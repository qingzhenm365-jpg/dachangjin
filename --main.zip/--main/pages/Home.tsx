import React from 'react';
import { useNavigate } from 'react-router-dom';
import { FEATURES, LEGACY_ITEMS, HOME_HERO_IMAGE } from '../constants';

const Home: React.FC = () => {
  const navigate = useNavigate();

  return (
    <div className="flex flex-1 flex-col items-center py-5 px-4 md:px-10 lg:px-40 w-full">
      <div className="layout-content-container flex flex-col max-w-[1200px] flex-1 w-full gap-12">
        
        {/* Hero Section */}
        <section className="@container w-full">
          <div className="@[480px]:p-4 p-0">
            <div 
              className="relative flex min-h-[560px] flex-col gap-6 overflow-hidden rounded-xl bg-cover bg-center bg-no-repeat @[480px]:gap-8 items-start justify-end px-6 pb-12 @[480px]:px-12 shadow-xl group"
              style={{
                backgroundImage: `linear-gradient(rgba(0, 0, 0, 0.1) 0%, rgba(0, 0, 0, 0.6) 100%), url("${HOME_HERO_IMAGE}")`
              }}
            >
              {/* Subtle zoom effect on bg */}
              <div className="absolute inset-0 bg-black/10 transition-colors group-hover:bg-black/0" />
              
              <div className="flex flex-col gap-4 text-left max-w-2xl z-10">
                <span className="text-primary font-bold tracking-widest uppercase text-sm bg-black/30 backdrop-blur-md px-3 py-1 rounded w-fit border border-primary/30">
                  Dae Jang Geum
                </span>
                <h1 className="text-white text-5xl md:text-6xl font-black leading-tight tracking-[-0.033em] drop-shadow-sm">
                  The Great Physician & Chef
                </h1>
                <h2 className="text-gray-100 text-lg md:text-xl font-normal leading-relaxed drop-shadow-md max-w-xl">
                  Uncovering the true history of Jang-geum, the first female royal physician of the Joseon Dynasty. A legacy of culinary art and medical innovation.
                </h2>
              </div>
              <div className="flex gap-4 flex-wrap z-10">
                <button 
                  onClick={() => navigate('/cuisine')}
                  className="flex min-w-[84px] cursor-pointer items-center justify-center overflow-hidden rounded-lg h-12 px-6 bg-primary text-[#0e1b12] text-base font-bold leading-normal tracking-[0.015em] hover:bg-white hover:text-primary transition-colors shadow-lg shadow-green-900/20"
                >
                  <span className="truncate">Start the Journey</span>
                </button>
                <button className="flex min-w-[84px] cursor-pointer items-center justify-center overflow-hidden rounded-lg h-12 px-6 bg-white/20 backdrop-blur-md border border-white/30 text-white text-base font-bold leading-normal tracking-[0.015em] hover:bg-white/30 transition-colors">
                  <span className="truncate">Watch Documentary</span>
                </button>
              </div>
            </div>
          </div>
        </section>

        {/* Feature Section: Meaning of Dae */}
        <section className="flex flex-col gap-10 px-4 py-6">
          <div className="flex flex-col gap-6 text-center items-center">
            <h1 className="text-text-main dark:text-white tracking-tight text-[32px] md:text-5xl font-black leading-tight max-w-[800px]">
              The Meaning of <span className="text-primary">'Dae'</span> (The Great)
            </h1>
            <p className="text-text-main dark:text-gray-300 text-lg font-normal leading-relaxed max-w-[720px]">
              The title 'Dae' was a unique honor bestowed upon Jang-geum by King Jungjong, signifying her exceptional skills and status as 'The Great Jang-geum'. It remains a rare distinction for a woman in the 16th century Joseon era.
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-4">
            {FEATURES.map((feature, idx) => (
              <div key={idx} className="flex flex-1 gap-4 rounded-xl border border-[#d0e7d7] dark:border-[#1a3322] bg-white dark:bg-[#1a3322]/50 p-6 flex-col hover:shadow-lg transition-all duration-300 hover:-translate-y-1">
                <div className="text-text-main dark:text-primary bg-[#e7f3eb] dark:bg-[#112116] w-12 h-12 rounded-full flex items-center justify-center">
                  <span className="material-symbols-outlined">{feature.icon}</span>
                </div>
                <div className="flex flex-col gap-2">
                  <h2 className="text-text-main dark:text-white text-xl font-bold leading-tight">{feature.title}</h2>
                  <p className="text-text-sub dark:text-gray-400 text-sm font-normal leading-normal">
                    {feature.description}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Legacy Section */}
        <section className="w-full">
          <div className="w-full flex items-center justify-between border-b border-[#e7f3eb] dark:border-[#1a3322] pb-4 pt-8 mb-6">
            <h2 className="text-text-main dark:text-white text-[28px] font-bold leading-tight tracking-[-0.015em]">The Three Pillars of Legacy</h2>
            <a href="#" className="text-primary text-sm font-bold hover:underline flex items-center gap-1">
              View all topics <span className="material-symbols-outlined text-sm">arrow_forward</span>
            </a>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 w-full pb-10">
            {LEGACY_ITEMS.slice(0, 2).map((item, idx) => (
              <div key={idx} className="flex flex-col items-stretch justify-start rounded-xl shadow-sm border border-[#e7f3eb] dark:border-[#1a3322] bg-white dark:bg-[#112116] overflow-hidden group hover:shadow-md transition-all">
                <div 
                  className="w-full bg-center bg-no-repeat aspect-video bg-cover transform group-hover:scale-105 transition-transform duration-500" 
                  style={{ backgroundImage: `url("${item.image}")` }}
                />
                <div className="flex w-full min-w-72 grow flex-col items-stretch justify-center gap-1 p-6 z-10 bg-white dark:bg-[#112116]">
                  <div className="flex items-center gap-2 mb-2">
                    <span className="material-symbols-outlined text-primary">{item.icon}</span>
                    <p className="text-text-main dark:text-white text-xl font-bold leading-tight tracking-[-0.015em]">{item.title}</p>
                  </div>
                  <p className="text-text-sub dark:text-gray-400 text-base font-normal leading-normal mb-4">
                    {item.description}
                  </p>
                  <button 
                    onClick={() => item.link ? navigate(item.link) : null}
                    className="flex w-full cursor-pointer items-center justify-center overflow-hidden rounded-lg h-10 px-4 bg-[#e7f3eb] dark:bg-[#1a3322] text-primary dark:text-primary text-sm font-bold leading-normal hover:bg-primary hover:text-[#0e1b12] transition-colors"
                  >
                    {item.cta}
                  </button>
                </div>
              </div>
            ))}

            {/* Full Width Card */}
            {LEGACY_ITEMS.slice(2, 3).map((item, idx) => (
              <div key={idx} className="lg:col-span-2 flex flex-col md:flex-row items-stretch justify-start rounded-xl shadow-sm border border-[#e7f3eb] dark:border-[#1a3322] bg-white dark:bg-[#112116] overflow-hidden group hover:shadow-md transition-all">
                <div 
                  className="w-full md:w-1/2 bg-center bg-no-repeat bg-cover min-h-[200px]" 
                  style={{ backgroundImage: `url("${item.image}")` }}
                />
                <div className="flex w-full md:w-1/2 grow flex-col items-stretch justify-center gap-2 p-6 md:p-8">
                  <div className="flex items-center gap-2">
                    <span className="material-symbols-outlined text-primary">{item.icon}</span>
                    <p className="text-text-main dark:text-white text-xl font-bold leading-tight tracking-[-0.015em]">{item.title}</p>
                  </div>
                  <p className="text-text-sub dark:text-gray-400 text-base font-normal leading-normal mb-4">
                    {item.description}
                  </p>
                  <div className="flex gap-4 mt-2">
                    <button className="flex min-w-[120px] cursor-pointer items-center justify-center overflow-hidden rounded-lg h-10 px-4 bg-primary text-[#0e1b12] text-sm font-bold leading-normal hover:bg-green-400 transition-colors">
                      {item.cta}
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
};

export default Home;
