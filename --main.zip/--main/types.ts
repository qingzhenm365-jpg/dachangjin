export interface Ingredient {
  name: string;
  benefit: string;
  image: string;
}

export interface Dish {
  id: string;
  name: string;
  subName: string;
  description: string;
  image: string;
  tags: {
    text: string;
    colorClass: string;
    icon?: string;
  }[];
  stats: {
    icon: string;
    label: string;
  }[];
  active?: boolean;
  keyIngredients?: string[];
}

export interface FeatureCardData {
  icon: string;
  title: string;
  description: string;
}

export interface LegacyCardData {
  title: string;
  description: string;
  image: string;
  cta: string;
  icon: string;
  link?: string;
}
