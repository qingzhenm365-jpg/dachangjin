import React from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';

const Header: React.FC = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const isCuisine = location.pathname.includes('cuisine');

  const navLinks = [
    { name: 'Home', path: '/' },
    { name: 'History', path: '/' },
    { name: 'Cuisine & Medicine', path: '/cuisine' },
    { name: 'Archives', path: '/' },
  ];

  return (
    <header className="sticky top-0 z-50 flex items-center justify-between whitespace-nowrap border-b border-solid border-[#e7f3eb] dark:border-white/10 bg-background-light/95 dark:bg-background-dark/95 backdrop-blur-md px-4 sm:px-10 py-3 transition-colors duration-300">
      <div className="flex items-center gap-8">
        <Link to="/" className="flex items-center gap-3 text-text-main dark:text-white group">
          <div className="size-8 text-primary flex items-center justify-center rounded-lg bg-primary/10 group-hover:bg-primary group-hover:text-white transition-all">
            <span className="material-symbols-outlined" style={{ fontSize: '24px' }}>
              {isCuisine ? 'local_pharmacy' : 'local_florist'}
            </span>
          </div>
          <h2 className="text-lg font-bold leading-tight tracking-[-0.015em] hidden sm:block">
            Dae Jang Geum Science
          </h2>
        </Link>
        
        <nav className="hidden lg:flex items-center gap-9">
          {navLinks.map((link) => (
            <Link
              key={link.name}
              to={link.path}
              className={`text-sm font-medium transition-colors ${
                location.pathname === link.path 
                  ? 'text-primary font-bold' 
                  : 'text-text-main dark:text-gray-200 hover:text-primary'
              }`}
            >
              {link.name}
            </Link>
          ))}
        </nav>
      </div>

      <div className="flex flex-1 justify-end gap-4 sm:gap-8">
        <label className="hidden sm:flex flex-col min-w-40 !h-10 max-w-64">
          <div className="flex w-full flex-1 items-stretch rounded-lg h-full bg-[#e7f3eb] dark:bg-white/10 border border-transparent focus-within:border-primary transition-colors">
            <div className="text-text-sub flex items-center justify-center pl-3">
              <span className="material-symbols-outlined" style={{ fontSize: '20px' }}>search</span>
            </div>
            <input
              className="flex w-full min-w-0 flex-1 bg-transparent px-3 text-sm text-text-main dark:text-white placeholder:text-text-sub focus:outline-none border-none focus:ring-0"
              placeholder={isCuisine ? "Search ingredients..." : "Search topics..."}
            />
          </div>
        </label>
        <button 
          onClick={() => alert("Subscribed!")}
          className="flex min-w-[84px] cursor-pointer items-center justify-center rounded-lg h-10 px-4 bg-primary hover:bg-primary-dark text-white text-sm font-bold shadow-sm transition-all hover:shadow-md"
        >
          <span>Subscribe</span>
        </button>
      </div>
    </header>
  );
};

export default Header;
