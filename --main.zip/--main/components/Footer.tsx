import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="w-full border-t border-[#e7f3eb] dark:border-white/10 pt-10 pb-6 bg-white dark:bg-surface-dark transition-colors duration-300">
      <div className="max-w-[1200px] mx-auto px-4 md:px-10 flex flex-col md:flex-row justify-between items-center gap-6">
        <div className="flex items-center gap-2 text-text-main dark:text-white">
          <div className="size-6 flex items-center justify-center text-primary">
            <span className="material-symbols-outlined">local_florist</span>
          </div>
          <span className="font-bold text-lg">Dae Jang Geum Science</span>
        </div>
        <div className="flex gap-8 text-text-sub text-sm flex-wrap justify-center">
          <a className="hover:text-primary transition-colors" href="#">About Us</a>
          <a className="hover:text-primary transition-colors" href="#">References</a>
          <a className="hover:text-primary transition-colors" href="#">Contact</a>
          <a className="hover:text-primary transition-colors" href="#">Privacy Policy</a>
        </div>
        <div className="text-text-sub dark:text-gray-500 text-sm">
          © 2024 Dae Jang Geum Science. All rights reserved.
        </div>
      </div>
    </footer>
  );
};

export default Footer;
