import { Dish, FeatureCardData, Ingredient, LegacyCardData } from './types';

export const INGREDIENTS: Ingredient[] = [
  {
    name: "Ginseng",
    benefit: "Restores energy",
    image: "https://lh3.googleusercontent.com/aida-public/AB6AXuC4LYJDG8VZwgO47JsK55stbzmwUB_Oen6ecvEq7FFdQVWlCnX51NCZ024q4GOEgKJX6CpBlA_HST75BTyxM_FPF12xU-gdhmHnkxjB4Nen2ds4yn0gxu3pV9FuvcS3o9bCpT2prd1EXDAurfU6lgGq4cRquyO6oKzer4y_qNIuwTvd601XJ2NzOUnNMUwWnscqnZdqrqt3FHNHBFyzRHClenIH0AToOz8cF3gISZv47H6ExcaNYQRS5LxpZ_0JX2zwyW37CwVV8SDY"
  },
  {
    name: "Ginger",
    benefit: "Warms stomach",
    image: "https://lh3.googleusercontent.com/aida-public/AB6AXuC27GZ0B3_iA8jfU-fpyH3r8v_Fy4-lW61m2LDWNtc4R388mTOaxFwANay2qb_Yj6d6el9Q0PVL459FDN5vh-30eKcAvzSvyCTsMmlQqI4rivYRIJSPvLPpV9ulFpbypc_iWShcDEHJCNUcXhsVA7w8tI196jiQ-hQHXDPXwoDlddDTC1QwGFkmmI46WsBxxlP3uEcu3S7JmzxYCT6jlL1ii62JS5LrZbJ-iHgYEJR8jgErDs7RdeXIHzshJqj4f8Vj_hkyi-RwJ566"
  },
  {
    name: "Jujube",
    benefit: "Calms the mind",
    image: "https://lh3.googleusercontent.com/aida-public/AB6AXuDg5mW0Sq6IQ51mdT1I_jxB4mkdc9FCOdVIJfMhBrdbcrKrCOQyPPzR5xQ-A-rfePEInXaCiX8ZqiF9YpJYu7Io7_jkXI2jIutis-VSRtUquwY6wFk7wBfXjtQxv-xDrXgdJLELgsonWnVSmypWbwgOfik8EQ-O3phcOz-wqSAg93_ucHPqpoC8rZnbBXKRu-lMnhOeqdVb-tJ3-aAlp9_sa8pjqb1yr7Fjuyo2g9xqJquGFgR4uS7XUMmPyf1cVSRpneL6r4QeuhVP"
  },
  {
    name: "Lotus Root",
    benefit: "Purifies blood",
    image: "https://lh3.googleusercontent.com/aida-public/AB6AXuAmCoUwrD7wIJGJvuTBiPgWMckJEMzsppZhuBjZXO9qp_TwmHjseumznLh2StNP6Q5BMIVWQJ-kGWHLSTXxy9NzPX58J5NqG1Krvkyqj-C3CS6GHIYejccL2k4b0qQAJQf96SD0aAS2bsofJXx5zMiJbaUZ5dI5i461kMSCaW-oEariSDEqaa5yFFyv15HG2y9ebVkPy20hLdpgTNAwPvt6SCowmKxmana3m-OlFenNsD0yR17NGW691Ltb3uzp860NtpoocfQMZZX2"
  }
];

export const DISHES: Dish[] = [
  {
    id: "1",
    name: "Samgyetang",
    subName: "Ginseng Chicken Soup",
    description: "A traditional summer dish to combat heat with heat. Stuffed with glutinous rice, ginseng, jujube, and garlic.",
    image: "https://lh3.googleusercontent.com/aida-public/AB6AXuADsCCnixxtzsgUEmZPk1a2YZgpmd44zbVUat_DbPPNydATzyjiRNQ8Y9QDzbgUK7Szc-AWGA6N_lSgOT4AC6WTdJcup6tEuMy_7pn7c4-W7DIE7rrSfNdhwt9aUoUshFtAZFiotHOadps5g5qWHFEKKQnaIgkO86aif0iCIPqfww0vBtU5fHUcyvcmgBtJkgb3ZKfOfPdJqoxHQNXO-UthON9wIJE8rZ6rnEzGA7eHgyZYMhVbnFpdzzjbRKu2WjWWLI7v539LIUfT",
    tags: [{ text: "Energy Boost", colorClass: "bg-primary/90" }],
    stats: [
      { icon: "thermometer", label: "Warming" },
      { icon: "timer", label: "2 hr cook" }
    ]
  },
  {
    id: "2",
    name: "Hobak-juk",
    subName: "Pumpkin Porridge",
    description: "Rich in carotene and vitamins. A soothing meal often served to recovering patients to restore appetite and reduce swelling.",
    image: "https://lh3.googleusercontent.com/aida-public/AB6AXuBGHrK6XBljPWkrX7GtA_tKh6rrCC46EM1o4yxtRQJQZo5WhJQkWqUofyFQ7ng1wHRR_4y4ijCldnM5OH7UHMSlJ6pAdpB3s8oGc5OMd_I4RIPgi5BTyiPHuMSaNrn6W1nd7_2Q91WUIZFhu1HTZQhw9fhbU_ombc6qKPbuQC6j9gyqUuXtWkbFp9Glb9CE2nnDuIM2yYotZIrdUMjPTcz2cWukPwTZNcUxdnha-SrgCMSrE11uN2-zjkmJClKkOySiNWNYDUKcmNlY",
    tags: [{ text: "Digestion", colorClass: "bg-blue-500/90" }],
    stats: [
      { icon: "spa", label: "Neutral" },
      { icon: "timer", label: "45 min" }
    ]
  },
  {
    id: "3",
    name: "Bibimbap",
    subName: "Royal Mixed Rice",
    description: "Based on the philosophy of Obangsaek (five colors). Each color represents a direction and an organ of the body.",
    image: "https://lh3.googleusercontent.com/aida-public/AB6AXuCmlDFX8fqc3cy1DRHlmBby5ncvaIEH1G4SifpChzy95zW5mg_daP6qhbZWCZbwFDYAotlpjCTVvQ0C1510F4Qwommej7a0w3-ZUsTwnsaLsaHPFVmKx89kJ7MF4TlP9FcNfD1YB-We0dNdO77MVYx6vJb4MjKyaxoHK9si_3KOCjZmhJv9BQ9D13wxXJ5GpxIoe-cq6dLLqHC2nz5K8cBlI69UlYnF73AIPQEdyZWueSX8OnzJTSqVBNlejJzb1lPJ_ZLD0P10G66O",
    tags: [{ text: "Balance", colorClass: "bg-purple-500/90" }],
    stats: [
      { icon: "balance", label: "Harmonizing" },
      { icon: "timer", label: "30 min" }
    ]
  },
  {
    id: "4",
    name: "Sinseollo",
    subName: "Royal Hot Pot",
    description: "A lavish dish representing harmony. It contains meatballs, fish pancakes, vegetables, and gingko nuts arranged by color.",
    image: "https://lh3.googleusercontent.com/aida-public/AB6AXuAa0iopLu-EQxdwphTkkPgWb-gyc-IZeEQKxjrf2KERRswzxLrMfJMjVetfgvKGnAfJyH1S4s6-S91iExyAyj67tvp1QcdNgqJQ_OnX9DKKn1Qy6WKoesvXtNt6U-ec7EYYuhIgefxd7w2nFqEhA2QVAjz947WYwoJXN2Stm00r4o0cwlP7U7AoH0FGkzn6FHCi70VTWf1v-_xUB88DLWbyOpvMoi5-N9gBf4vNj7jmf2LmpkmKA6HFdcPxN2ibJsuXwTeR43BjtLSR",
    tags: [{ text: "Immunity", colorClass: "bg-orange-500/90" }],
    stats: [
      { icon: "thermometer", label: "Warming" },
      { icon: "timer", label: "3 hr cook" }
    ]
  },
  {
    id: "5",
    name: "Galbi-jjim",
    subName: "Braised Short Ribs",
    description: "Beef ribs slow-cooked with chestnut, carrots, and medicinal herbs. Strengthens the bones and tendons.",
    image: "https://lh3.googleusercontent.com/aida-public/AB6AXuBg7sD68O9QQcWYNuwXJFnvWM7G0bbt7DKYARm6TSi-B-5cLtnDy7Fj81bqRPq3j5Sw7wp-z_X2uqDv_JA3td1FXg-V7qVTOnXCMkAJqUkl93cZGv8HNXSbN-NMxX0NZtLvKkWcemK3dJbgaDyCbu50e4kj_cBGYmMO42o2nLjAwJWpg_Swyua8JI0YgeKZGSVFkP8QHkQUUd4h28qoVlrHubihFGO_Y-EH2BoZbESZhfxNN1Y93QOQkBqypUNQ15jIwLdtCRYM4BVY",
    tags: [{ text: "Vitality", colorClass: "bg-red-500/90" }],
    stats: [
      { icon: "thermometer", label: "Warm" }
    ],
    active: true,
    keyIngredients: [
      "https://lh3.googleusercontent.com/aida-public/AB6AXuDtSGYh3rvAds1lXefle2vN4rq4jHIYOHs59wlhS3vyanLdiD9V74vk8I-TO2QWNkmmkxRf3Xvi1_iKOT6IHd7REKwxwSuthRKGGTAIzz84CUuQX5B28ACbffsqsUSuWsPqADvFZ_fxB8DyTEfLLpYawstxQptS1QTH3mN6c5MR56vlqch3fcKujz2K3cjS6UycSPYXx9jaYJySOfAghvvA4V2vXprSjrNV5v05NBTly-LOFw29-QCkTY39EjKAtDBsuWBbpevs9k4u",
      "https://lh3.googleusercontent.com/aida-public/AB6AXuDSeCqHXPYSmzAGjFkL4R57f6RFSHKSKmNm0IyPrDs_sroVKxOdbQqgxeaKgNLpCSQ0FLF5UAximVbL0v_oacl2lWQo1kau5xHRAvwHEds1omhOvuqGI5c4kqXdtWWQU9Bz9wcRz3gsUljCnvL8lu_wuJtpQVZoFQulenRQ9_UOO5D0M99PU4JF1Rw485AlcWTj6i526ZU3QsnHvbo7zeS81OLgatr0exiYHIuw0nq6iknomhGAdxYcIURWGDv53d731IZbrh5eq5HJ",
      "https://lh3.googleusercontent.com/aida-public/AB6AXuDXHSryeOU-YMReTlk0vNQbWeE76rLwuH7JaxHZpB-H5P88wcTdwFIbPYYnNSNyuYOlKmBl4Ssjmuvt6fuZbbxSVZqxQ0hIF54UFLtsWmj6koeb--mOXs2EaSwV3kCB7YZRlmVNnjdkOQkUiJ6anPgDqwm3YUHOXz-Y0zGRqyHp2Ey_FCg0KCV0JqJZbjspYF70-b7XVod7btSzmraq7W-4dcZ0wC_IyL_dqc1mBBUjjQdV_BIGIi3VX1eGxVlYeFnm9Y12XPQiqZAc"
    ]
  },
  {
    id: "6",
    name: "Dotorimuk",
    subName: "Acorn Jelly Salad",
    description: "Made from acorn starch, this dish is low in calories and helps detoxify heavy metals from the body.",
    image: "https://lh3.googleusercontent.com/aida-public/AB6AXuDMfg3-cU2oMpbZ5FI0F0pSQlq9wuCZ5DxK-DINEaUsBMf4hbXeXHUAIUawBSFRsQRXevnJnMCUazw6cEdaqTwakrWgU9QDQxisBMxcnmSLgdrm24Egyl3kukB9DkgX_I_GxqsTf4ONx3o9ikmRNJ6RZwqfS0hKvnaP6SssW-Cb_BYx-ltU07LE33rFDkHTDObWQGf4-wnZWDuYUWVF9Y7G-euS21RmWscD2kgUGrnv56jP1f2HqbKoyRreBcQAyf8uCzC2A-PL594E",
    tags: [{ text: "Detox", colorClass: "bg-green-600/90" }],
    stats: [
      { icon: "ac_unit", label: "Cooling" },
      { icon: "timer", label: "15 min" }
    ]
  }
];

export const FEATURES: FeatureCardData[] = [
  {
    icon: "stethoscope",
    title: "Royal Physician",
    description: "The only woman to serve as the King's personal physician in Korean history, breaking centuries of tradition."
  },
  {
    icon: "soup_kitchen",
    title: "Culinary Master",
    description: "Championing the philosophy \"Yak-sik-dong-won\" — that food and medicine share the same origin."
  },
  {
    icon: "history_edu",
    title: "Cultural Icon",
    description: "A symbol of perseverance, intelligence, and humanity that continues to inspire generations worldwide."
  }
];

export const LEGACY_ITEMS: LegacyCardData[] = [
  {
    title: "Imperial Cuisine",
    description: "Discover the complex and balanced recipes served to the King, designed to harmonize the body's energy.",
    image: "https://lh3.googleusercontent.com/aida-public/AB6AXuCZpaGDDJk48GDMYkfl-gwBAfpiynW2erCY6FCjhVzkpWgwPUz8CYalF4-z3PFnIuOxuUGwbWQiAL2jMPYlniWkaIwHx-vuRjI3_69JVW1VIAX_r7NozcloZgrXSo4prKZshYa1Jj4Wtu1RYEHgmJ7PLxrIa091pORXTwbkJ5FQ1EJX3VTnHhaS44TzzgTr-IfxbiT5NiQyohIP3ifrw-8aCVSuLH3VTAdaJk6SkTKLinAHJs8JczpMAofM1UVwA2jnyHGqam9sB11v",
    cta: "Explore Recipes",
    icon: "nutrition",
    link: "/cuisine"
  },
  {
    title: "Medical Achievement",
    description: "From pulse diagnosis to herbal remedies, learn how Jang-geum revolutionized royal medical practices.",
    image: "https://lh3.googleusercontent.com/aida-public/AB6AXuBtJw0NIIzo6e0sCqxKfoopaZ4FS0yg95kQ9cAYSgwTlIHXp25Wt34EvnEEWwp1ehXL_CGJn6-T8tyGYop1WUskUTzwdFNOUgx3CAsuvOTdeV6pe1LCfVqow9zA1WBA_WV27L1YbLBQCrNmVfbJVUEI179rZJ0g82qU5mw0QKxAf2sdnWE0x-OnnBzPxEJyvPrJtkEbijGvtThxvkNlo-qiamTn0PMLCsSuTIJCv_0TPeEbyVc7GXdmyT3EmK1EIvJRV8EWCg6uErW7",
    cta: "View Medical Records",
    icon: "healing"
  },
  {
    title: "Historical Truth vs. Drama",
    description: "The \"Annals of the Joseon Dynasty\" mentions Jang-geum over 10 times. Separate the historical facts from the popular TV dramatization.",
    image: "https://lh3.googleusercontent.com/aida-public/AB6AXuDe9XOGmhapchToaW_GeEky4wgRU_A0nXf7lPb0vNxyGxbyzvjB57h2k2iNnFsXpT9szB_M8Lbza_7vbGZJcaycVIZ51mvRBqTdvjLzgCHzYtqQeH7dxb0jGlxSKSRyGf7GElnTMM5ehElpY4scxmPMuEl3hxkk6AFyG8c4tx59dBe56s8FhsCIuFiXrgQ5CA_oXPEBfxJOtn6HzQfSr3U2o4CK3mOydSf8kPE5DMVr3AATYeYJNwgSuIYUwKxKJF8i9qT__U9rSUvW",
    cta: "Read History",
    icon: "auto_stories"
  }
];

export const HOME_HERO_IMAGE = "https://lh3.googleusercontent.com/aida-public/AB6AXuDph2_szXwRFCwRLkQLgm9YFCgMRBAXnds_5cPQUio5XaX5D9Y5_OAhFgPRQKJiRDbV4GJDpm1SFRi6BzztW-2G18RZG0oqEXjF_ReueAxHbQPOhmTUwvVCbGQhKcn7lMrMbcyVfH6jq-5IGVnMT5xgp9CmJML8EdRDCBkELJ2EmMrrqeaU6BF19L39GhKRijGVpp8Vw8bKUBkSvYpe33UOYgaILo_tKXSgAA9kC_l0MFMZPWwFdlFshWouYKI7Bc92Z_ZZVgXe8le4";
