import React from 'react';
import { HashRouter as Router, Routes, Route, useLocation } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import Home from './pages/Home';
import Cuisine from './pages/Cuisine';

const Layout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const location = useLocation();
  const isCuisine = location.pathname.includes('cuisine');

  return (
    <div className="relative flex h-auto min-h-screen w-full flex-col overflow-x-hidden">
      <Header />
      {children}
      {/* Cuisine page has its own footer inside because of the sidebar layout, but Home needs global footer. 
          For simplicity, we conditionally render global footer if not on cuisine, or handle it inside pages.
          Looking at design, Home footer is global. Cuisine footer is inside main content.
      */}
      {!isCuisine && <Footer />}
    </div>
  );
};

const App: React.FC = () => {
  return (
    <Router>
      <Layout>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/cuisine" element={<Cuisine />} />
        </Routes>
      </Layout>
    </Router>
  );
};

export default App;
