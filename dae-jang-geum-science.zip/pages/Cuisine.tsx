import React from 'react';
import { INGREDIENTS, DISHES } from '../constants';

const Cuisine: React.FC = () => {
  return (
    <div className="flex flex-1 flex-col lg:flex-row w-full max-w-[1920px] mx-auto">
      {/* Sidebar Navigation */}
      <aside className="hidden lg:flex w-72 flex-col gap-6 border-r border-[#e7f3eb] dark:border-white/10 bg-background-light dark:bg-background-dark p-6 sticky top-[65px] h-[calc(100vh-65px)] overflow-y-auto hide-scroll">
        <div className="flex flex-col gap-1">
          <h1 className="text-lg font-bold text-text-main dark:text-white">Imperial Cuisine</h1>
          <p className="text-text-sub text-xs uppercase tracking-wider font-semibold">Medicine & Food Source</p>
        </div>
        <nav className="flex flex-col gap-2">
          <a href="#" className="flex items-center gap-3 px-3 py-2.5 rounded-lg bg-primary/10 text-primary transition-colors">
            <span className="material-symbols-outlined fill-current">restaurant_menu</span>
            <p className="text-sm font-medium">All Dishes</p>
          </a>
          {["Digestive Health", "Vitality & Energy", "Cold Season Care", "Detoxification"].map((item, idx) => (
            <a key={idx} href="#" className="flex items-center gap-3 px-3 py-2.5 rounded-lg hover:bg-[#e7f3eb] dark:hover:bg-white/5 text-text-main dark:text-gray-300 transition-colors group">
              <span className="material-symbols-outlined group-hover:text-primary transition-colors">
                {idx === 0 ? "eco" : idx === 1 ? "favorite" : idx === 2 ? "ac_unit" : "spa"}
              </span>
              <p className="text-sm font-medium">{item}</p>
            </a>
          ))}
        </nav>
        
        <div className="mt-4 pt-4 border-t border-[#e7f3eb] dark:border-white/10">
          <h3 className="text-xs font-bold text-text-sub uppercase mb-3 px-3">Yak-seon Glossary</h3>
          <div className="flex flex-col gap-3 px-3">
            {[
              { title: "Qi (气)", desc: "The vital life force that flows through the body. Balanced through warming foods." },
              { title: "Yin & Yang", desc: "The duality of cooling (Yin) and warming (Yang) energies in ingredients." },
              { title: "Five Flavors", desc: "Sour, bitter, sweet, spicy, and salty - each corresponding to an organ system." }
            ].map((term, idx) => (
              <div key={idx} className="group cursor-pointer">
                <p className="text-sm font-bold text-text-main dark:text-white group-hover:text-primary transition-colors">{term.title}</p>
                <p className="text-xs text-text-sub line-clamp-2 mt-0.5">{term.desc}</p>
              </div>
            ))}
          </div>
        </div>

        <div className="mt-auto p-4 rounded-xl bg-[#e7f3eb] dark:bg-white/5 flex flex-col gap-3">
          <div className="flex items-center gap-2 text-primary">
            <span className="material-symbols-outlined">menu_book</span>
            <span className="text-sm font-bold">Daily Wisdom</span>
          </div>
          <p className="text-xs text-text-main dark:text-gray-300 italic">"Food is the best medicine. Treat the root cause, not just the symptom."</p>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col min-w-0">
        
        {/* Hero Section */}
        <div className="relative w-full bg-[#1e3a29] overflow-hidden">
          <div className="absolute inset-0 opacity-20" style={{ backgroundImage: "url('data:image/svg+xml,%3Csvg width=\\'60\\' height=\\'60\\' viewBox=\\'0 0 60 60\\' xmlns=\\'http://www.w3.org/2000/svg\\'%3E%3Cg fill=\\'none\\' fill-rule=\\'evenodd\\'%3E%3Cg fill=\\'%23ffffff\\' fill-opacity=\\'0.4\\'%3E%3Cpath d=\\'M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z\\'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E')" }}></div>
          <div className="absolute inset-0 bg-gradient-to-r from-background-dark/80 to-transparent"></div>
          <div className="relative z-10 max-w-5xl mx-auto px-4 sm:px-8 py-12 lg:py-20 flex flex-col gap-4">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/10 border border-white/20 w-fit backdrop-blur-sm">
              <span className="w-2 h-2 rounded-full bg-primary animate-pulse"></span>
              <span className="text-xs font-medium text-white tracking-wide">Yak-seon Philosophy</span>
            </div>
            <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white leading-tight max-w-2xl">
              Where Culinary Art Meets <span className="text-primary">Medicinal Science</span>
            </h1>
            <p className="text-gray-300 text-base md:text-lg max-w-xl leading-relaxed">
              Explore the ancient wisdom of the Royal Court. In traditional Korean medicine, food and medicine share the same origin. Restore your balance with nature's ingredients.
            </p>
            <div className="flex flex-wrap gap-4 mt-4">
              <button className="flex items-center gap-2 bg-primary hover:bg-primary-dark text-white px-6 py-3 rounded-lg font-bold transition-all shadow-lg hover:shadow-green-900/30">
                <span>Explore Dishes</span>
                <span className="material-symbols-outlined" style={{ fontSize: '20px' }}>arrow_forward</span>
              </button>
              <button className="flex items-center gap-2 bg-white/10 hover:bg-white/20 text-white px-6 py-3 rounded-lg font-bold transition-all border border-white/20 backdrop-blur-sm">
                <span className="material-symbols-outlined" style={{ fontSize: '20px' }}>play_circle</span>
                <span>Watch Introduction</span>
              </button>
            </div>
          </div>
        </div>

        {/* Featured Ingredients Strip */}
        <div className="w-full bg-white dark:bg-surface-dark border-b border-[#e7f3eb] dark:border-white/10">
          <div className="max-w-7xl mx-auto px-4 sm:px-8 py-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-bold text-text-sub uppercase tracking-wider">Key Medicinal Ingredients</h3>
              <a href="#" className="text-sm font-medium text-primary hover:underline">View Glossary</a>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {INGREDIENTS.map((ingredient, idx) => (
                <div key={idx} className="flex items-center gap-3 p-3 rounded-lg bg-background-light dark:bg-background-dark border border-[#e7f3eb] dark:border-white/5 hover:border-primary/50 transition-colors group cursor-pointer">
                  <div 
                    className="w-12 h-12 rounded-full bg-cover bg-center shrink-0 border border-white/20"
                    style={{ backgroundImage: `url("${ingredient.image}")` }}
                  />
                  <div className="flex flex-col">
                    <span className="text-sm font-bold text-text-main dark:text-white group-hover:text-primary transition-colors">{ingredient.name}</span>
                    <span className="text-xs text-text-sub">{ingredient.benefit}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Culinary Grid */}
        <div className="max-w-7xl mx-auto w-full px-4 sm:px-8 py-8 flex-1">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-6 gap-4">
            <h2 className="text-2xl font-bold text-text-main dark:text-white">Featured Medicinal Dishes</h2>
            <div className="flex items-center gap-2 p-1 bg-white dark:bg-surface-dark rounded-lg border border-[#e7f3eb] dark:border-white/10">
              <button className="p-2 rounded hover:bg-background-light dark:hover:bg-white/5 text-primary">
                <span className="material-symbols-outlined" style={{ fontSize: '20px' }}>grid_view</span>
              </button>
              <button className="p-2 rounded hover:bg-background-light dark:hover:bg-white/5 text-text-sub">
                <span className="material-symbols-outlined" style={{ fontSize: '20px' }}>view_list</span>
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6 pb-12">
            {DISHES.map((dish) => (
              <article 
                key={dish.id} 
                className={`group relative flex flex-col bg-white dark:bg-surface-dark rounded-2xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 border ${dish.active ? 'border-primary ring-4 ring-primary/10 scale-[1.02]' : 'border-[#e7f3eb] dark:border-white/5'}`}
              >
                {dish.active && (
                  <div className="absolute top-0 right-0 p-2 z-20">
                    <div className="bg-primary text-white rounded-full p-1">
                      <span className="material-symbols-outlined text-sm">check</span>
                    </div>
                  </div>
                )}
                
                <div className="relative h-64 overflow-hidden">
                  <div className="absolute top-4 left-4 z-10">
                    {dish.tags.map((tag, i) => (
                      <span key={i} className={`px-3 py-1 rounded-full text-white text-xs font-bold shadow-sm backdrop-blur-md ${tag.colorClass}`}>
                        {tag.text}
                      </span>
                    ))}
                  </div>
                  <div 
                    className="w-full h-full bg-cover bg-center transition-transform duration-700 group-hover:scale-105"
                    style={{ backgroundImage: `url("${dish.image}")` }}
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-60"></div>
                </div>

                <div className={`flex flex-col p-5 gap-3 ${dish.active ? 'bg-white dark:bg-surface-dark' : ''}`}>
                  <div className="flex justify-between items-start">
                    <div>
                      <h3 className="text-xl font-bold text-text-main dark:text-white group-hover:text-primary transition-colors">{dish.name}</h3>
                      <p className="text-sm text-text-sub font-medium">{dish.subName}</p>
                    </div>
                    <button className="text-text-sub hover:text-primary transition-colors">
                      <span className="material-symbols-outlined">bookmark_add</span>
                    </button>
                  </div>
                  
                  <p className="text-sm text-gray-600 dark:text-gray-400 line-clamp-2">{dish.description}</p>
                  
                  {dish.keyIngredients && (
                    <div className="flex flex-col gap-2 mt-2 bg-background-light dark:bg-black/20 p-3 rounded-lg">
                      <p className="text-xs font-bold text-text-sub uppercase">Key Ingredients:</p>
                      <div className="flex gap-2">
                        {dish.keyIngredients.map((img, i) => (
                          <div key={i} className="w-8 h-8 rounded-full bg-gray-200 bg-cover bg-center" style={{ backgroundImage: `url("${img}")` }} />
                        ))}
                      </div>
                    </div>
                  )}

                  <div className="mt-auto pt-4 flex items-center justify-between text-xs font-medium text-text-sub border-t border-[#e7f3eb] dark:border-white/10">
                    <div className="flex items-center gap-4">
                      {dish.stats.map((stat, i) => (
                        <div key={i} className="flex items-center gap-1">
                          <span className="material-symbols-outlined text-base">{stat.icon}</span>
                          <span>{stat.label}</span>
                        </div>
                      ))}
                    </div>
                    {dish.active && (
                       <button className="text-primary hover:text-primary-dark font-bold flex items-center gap-1">
                          View Recipe <span className="material-symbols-outlined text-sm">arrow_forward</span>
                      </button>
                    )}
                  </div>
                </div>
              </article>
            ))}
          </div>
          
          <div className="flex justify-center mb-8">
            <button className="px-6 py-3 rounded-lg border border-[#e7f3eb] dark:border-white/10 bg-white dark:bg-white/5 text-text-main dark:text-white font-medium hover:bg-background-light dark:hover:bg-white/10 transition-colors">
              Load More Dishes
            </button>
          </div>
        </div>
      </main>
    </div>
  );
};

export default Cuisine;
